package com.ecommerce;

public class Product{
    private String productID, productName;
    private double price;
    private int inventory;
    
    public Product(String prodID, String prodName, double price, int inv){
        this.productID = prodID;
        this.productName = prodName;
        this.price = price;
        this.inventory = inv;
        
    }

    public Product(){
        this.productID = "1234";
        this.productName = "Test Product";
        this.price = 1.0;
        this.inventory = 4;
    }
    
    public String getProductID(){
        return productID;
    }

    public String getProductName(){
        return productName;
    }
   
    public double getPrice(){
        return price;
    }
    public int getInventory(){
        return inventory;
    }
    public void setProductID(String prodID){
        this.productID = prodID;
    }

    public void setProductName(String productName){
        this.productName = productName;
    }

    public void setPrice(double newPrice){
        this.price = newPrice;
    }
    public void setInventory(int invLevel){
        this.inventory = invLevel;
    }
    public void lowerInv(int shoppingCart){
        if(this.inventory <= 0){
            System.out.println("The product is out of stock.");
        }else{
            this.inventory = this.inventory - shoppingCart;
        
        }
        
    }
    public void addInv(int shoppingCart){
        this.inventory = this.inventory + shoppingCart;
    }
    public String printInv(){
        String output = this.productID + " and the price is " + this.price;
        return output;
    }
}


