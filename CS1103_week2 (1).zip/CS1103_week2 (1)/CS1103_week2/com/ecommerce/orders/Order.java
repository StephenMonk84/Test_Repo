package com.ecommerce.orders;

import com.ecommerce.*;


public class Order {
    private String orderID;
    private Customer cust[] = new Customer[1];
    private double totalAmount;
    private boolean isSubmitted;

    public Order(String ordID, Customer cust){
        this.cust[0] = cust;
        this.orderID = ordID;
        this.isSubmitted = false;
        this.totalAmount = 0.0;
    }
    
    public Order(){
        this.orderID = "1234";
        cust[0]= new Customer("3456", "Bob");
        this.totalAmount = 55;
    }

    /*public void generateSummary(){
        System.out.println(cust[0].getCartItems());
        for(int i=0; i<cust[0].getCartItems().length; i++){
            System.out.println(cust[0].getCartItems() + " " + 0.0);
        }
    }*/
    public double getTotalAmount(){

        System.out.println(cust[0].totalCart());
        return cust[0].totalCart();
    }
}
